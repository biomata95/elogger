<!Doctype html>
<head>

  <meta charset="UTF-8">
</head>
<?php
	/* MANIPULAÇÕES BÁSICAS ENTRE AS VARIÁVEIS */	

	$teste1 =  'oi'; /* Atribui a palavra oi */
	$teste2 =  'beleza'; /* Atribui a palavra beleza */
	$teste3  = $teste1.' '.$teste2.'!';  /* Concatena a variavel $teste1 com $teste2 e atribui na $teste3 */
	echo $teste3;
	echo "<br>";
	echo 'teste1'; /* Imprime teste1 */
	echo "<br>";
	print 'teste2'; /* Imprime teste2 */
	echo "<br>";
	define('greeting','Oi tudo bem');  /* Coloca a frase Oi tudo bem, na 'variavel' greeting */
	echo greeting;
	
?>

