<?php
	
	/* COMANDOS REFERENTES AOS LOOPS, REPETIÇÕES */

	/*<===ESTRUTURA DE REPETIÇÃO FOR===>*/

	for($i = 5;$i <=10;$i++){ /* Neste loop a repetição começa do número 5 até o 10, aqui o valor é incrementado de um em um */
		echo 'Numero: '.$i;
		echo '<br>';
	}
	
	echo "<br>";

	for($i = 0;$i <=10;$i+=2){ /* Neste loop a repetição começa do número 0 até o 10, aqui o valor é incrementado de dois em dois */
		echo 'Numero: '.$i;
		echo '<br>';
	}

	echo "<br>";

	for($i = 10;$i >=0;$i--){ /* Neste loop a repetição começa do número 10 até o 00, aqui o valor é decrementado de um em um */
		echo 'Numero: '.$i;
		echo '<br>';
	}

	echo "<br>";

	for($i = 20;$i >=0;$i-=2){ /* Neste loop a repetição começa do número 20 até o 0, aqui o valor é decrementado de dois em dois */
		echo 'Numero: '.$i;
		echo '<br>';
	}

	echo "<br>";

	/*<===ESTRUTURA DE REPETIÇÃO WHILE===>*/
	/* Aqui o processador verifica se condição é verdadeira depois ele executa.  */

	$i = 0; /* Variável auxiliar contadora */
	while($i < 10){ /* Enquanto $i menor do que 10, ele fica imprimindo */
		echo $i;
		echo '<br>';
		$i++; /* incrementa contador */
	}

	/*<===ESTRUTURA DE REPETIÇÃO DO-WHILE===>*/
	/* Aqui o processador executa primeiro depois verifica se condição é verdadeira.  */

	$i = 0; /* Variável auxiliar contadora */

	echo '<br>';

	do{ /* Faça Enquanto $i for menor do que 10, ele fica imprimindo */
		echo $i;
		echo '<br>';
		$i++; /* incrementa contador */
	}while($i<10);

	$people = array	('Brad'=>'brad@gmail.com','Jose'=>'jose@gmail.com','William'=>'will@gmail.com'); 
/* declara array people */

	/*<===ESTRUTURA DE REPETIÇÃO FOR-EACH===>*/
	/* Neste exemplo abaixo, para cada item do arranjo o processador faz uma impressão do seu elemento */

	foreach($people as $person => $email){ /* Realiza iteração do vetor e imprime os elementos, imprime o nome e o email de cada individuo */
		echo $person.':'.$email;
		echo '<br>';
	}
	


?>
