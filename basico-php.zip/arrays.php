<!Doctype html>
<head>

  <meta charset="UTF-8">
</head>
<?php

	/* COMANDOS REFERENTES A ARRAYS(ARRANJOS/VETORES) */


	$people = array('fulano','beutro','akiles'); /* Declara um array de pessoas */
	$ids  = array(23,55,12); /* declara um array de numeros */
	$cars = ['Ford','Mercedes','Kia']; /* declara uma lista de carros, chamado cars */
	$cars[3] = 'Motors'; /* atribui à posição 3 da lista de carros a palavra Motors */
	$cars[] = 'BMW'; /* Atribui esta palavra na ultima posição do array cars */
	$cars[] = 10;  /* Atribui este inteiro na ultima posição do array cars */
	$cars[] = 1.7;  /* Atribui este número real na ultima posição do array cars */
	$cars[] = true;  /* Atribui este booleano na ultima posição do array cars */

	echo count($cars)."<br>";  /* Conta o numero de elemento do cars */	
	print_r($cars);  /* Imprime os elementos do array cars */
	echo "<br>";
	var_dump($cars);
	echo "<br>";
	
	echo $people[2]."<br>";  /* Retorna a segunda posição do arranjo people */ 
	echo $ids[2]."<br>";
	echo $cars[4]."<br>";

 	echo "<br>";
	echo "<br>";
	echo "<br>";


	$people = array('Brad' =>35,'Jose'=>32,'William'=>37);  /* Associa um nome a cada numero em um determinado array */
	echo "<br>";
	echo "<br>";
	$ids = [22=>'Brad',44=>'Jose',63=>'william']; /* Associa numero a cada nome em um determinado array */

	echo $people['Brad']."<br>"; 
	echo $ids['22']."<br>";	
	$people['Jill']=43;
	echo $people['Jill']."<br>";
	print_r($people);
	echo "<br>";
	var_dump($people);
	echo "<br>";


	// Atribuição de um Arranjo multidimensional, ou seja, matriz. O nome desta matriz eh cars //
	$cars = array(
		array('Honda',10,20),
		array('Toyota',34,48),
		array('Ford',50,25),	
	);

	echo "<br>";
	echo $cars[1][2];
	echo "<br>";
	echo $cars[1][0];

?>

