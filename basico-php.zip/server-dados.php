<?php
	/* IMPRIME INFORMAÇÕES TÉCNICAS A RESPEITO DA APLICAÇÃO, COMO VERSÃO DO BROWSER, PORTA UTILIZADA, PROTOCOLO DE REDE ENTRE OUTROS DADOS. */
    echo "<pre>";
    print_r($_SERVER); /* Imprime informações técnicas */
    echo "</pre>";
    echo $_SERVER[SCRIPT_FILENAME]."<br>";  /* Imprime caminho completo do arquivo onde ele se encontra na máquina */ 
?>
