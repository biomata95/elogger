<?php

	/* COMANDOS REFERENTES AO ENVIO DE INFORMAÇÕES PELA URL, COM OS MÉTODOS GET E POST */

	/*
	if(isset($_GET['name'])){
		print_r($_GET);
		$name = htmlentities($_GET['name']);
		echo $name;
	}
	*/
	if(isset($_POST['nome'])){ /* Ao clicar no botão submter, os dados do nome e email do usuário serão impressos na tela  */
		print_r($_POST);
		$name = htmlentities($_POST['nome']);
		echo $name;
	}
?>

<!DOCTYPE html>
<html>
	<head>
		<title>teste get-post</title>
	</head>
<body>
	<form method="POST" action="get-post.php"> <!-- O Método POST é usado neste formulário, no qual a ação ocorrerá no próprio código(get-post.php) -->
		<div>
			<label>Nome</label><br>
			<input type="text" name="nome">
		</div>
		<div>
			<labe>Email</label><br>
			<input type="text" name="email">			
		</div>
		<input type="submit" name="submit" value="Submeter">			
	</form>
</body>
</html>
