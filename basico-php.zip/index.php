<!Doctype html>
<head>

  <meta charset="UTF-8">
</head>
<h1><?php

	echo 'teste1';
?></h1>

