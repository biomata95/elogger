<?php

	/* COMANDOS REFERENTES A FUNÇÃO */

	function addFive(&$num){
		$num +=5;
		echo "<br>";
	}


	function addNumbers($num1,$num2){
		return $num1+$num2;
	}


	function sayHello($name = 'World'){	
		echo "Hello $name<br>";
		echo '<br>';
	}


	function simpleFunction(){
		echo 'Hello world'; /* Retorna apenas uma frase */
		echo '<br>';
	}


	simpleFunction(); /* Acessa a função simpleFunction() */

	sayHello('Joe'); /* Acesso a função sayHello com o nome enviado como parâmetro */
	echo addNumbers(2,3);  /* Acessa a função addNumbers que adiciona dois números enviados como parâmetros */

	$myNum = 10; /* Atribui variavel */
		
	addFive($myNum); /* Esta função adiciona 5 em qualquer numero enviado como parâmtro. Nesta função o parâmetro eh enviado como referência, ou seja, a variável é alterada em todo o código do programa se ela é enviada */
	
	echo "valor: $myNum<br>"; /* Imprime a variável enviada na função anterior */
?>
