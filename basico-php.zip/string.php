<?php

	/* COMANDOS REFERENTES À MANIPULAÇÃO DE STRINGS */

	/* variavel utiliza para os testes se chama $output*/

	$output = substr('Hello',0,3); /* Retorna os caracteres entre as posições 0-3 da palavra Hello */
	echo $output."<br>";
	$output = substr('Hello',1,3); /* Retorna os caracteres entre as posições 1-3 da palavra Hello */
	echo $output."<br>";
	$output = substr('Hello',-2); /* Retorna os dois últimos caracteres da palavra Hello */
	echo $output."<br>";

	$output = strlen('Hello World');  /* Retorna a quantidade de caracteres da palavra Hello World */
	echo $output."<br>";

	$output = strpos('Hello World','o');  /* Retorna a posição em que se encontra a letra 'o' na frase Hello World, pela primeira vez */
	echo $output."<br>";
	
	$output = strrpos('Hello World','o');  /* Retorna a posição em que se encontra a letra 'o' na frase Hello World, pela última vez */
	echo $output."<br>";

	$text = 'Hello World'; 
	var_dump($text);

	echo "<br>";

	$output = strtolower('Hello World'); /* Retorna a palavra Hello World toda em minúscula */
	echo $output."<br>";

	$output = strtoupper('Hello World'); /* Retorna a palavra Hello World toda em maiúscula */
	echo $output."<br>";

	$output = ucwords('isto eh um teste sobre php'); /* Retorna a palavra apenas com as iniciais de cada palavra em maiuscula */
	echo $output."<br>";

	$text = 'Hello World';
	$output = str_replace('World','Teste',$text);  /* Troca a palavra World por Teste */
	echo $output."<br>";

	$val = '22'; /* variável val */
	$output = is_string($val); /* verifica se a variavel val é string. Se for retorna 1, senão não retorna nada. Neste exemplo ela é porque está como '22' e não como 22. Como esta entre aspas o numero se torna string. ;) */
	echo $output."<br>";

	/* O values é um arranjo. */
	$values = array(true,false,null,'abc',33,'90',22.4,'54.4','',' ',0,'0.5');
	foreach($values as $value){ 	/* Este foreach, retorna apenas string do arranjo. */
		if(is_string($value)){
			echo "{$value} eh string <br>";
		}
	}	

	$texto = "A mula sem cabeça é uma lenda do folclore brasileiro. A sua origem é desconhecida, mas bastante evidenciada em todo o Brasil.

A mula é literalmente uma mula sem cabeça, que solta fogo pelo pescoço, local onde deveria estar sua cabeça. Possui em seus cascos, ferraduras que são de prata ou de aço e apresentam coloração marrom ou preta.

Segundo alguns pesquisadores, apesar de ter origem desconhecida, a lenda fez parte da cultura da população que vivia sob o domínio da Igreja Católica.

Segundo a lenda, qualquer mulher que namorasse um padre seria transformada em um monstro. Dessa forma, as mulheres deveriam ver os padres como uma espécie de “santo” e não como homem, se cometessem qualquer pecado com o pensamento em um padre, acabariam se transformando em mula sem cabeça."; /* Texto exemplo */

	$comprimida = gzcompress($texto); /* Compacata o texto no formato gz */
	echo $comprimida."<br><br>";

	echo $texto."<br><br>"; /* Imprime o texto original */
	

?>
