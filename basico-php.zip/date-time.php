<?php

	/* COMANDOS REFERENTES A DATA E HORA */

	echo date('d')."<br>"; /* Retorna o dia */
	echo date('m')."<br>"; /* Retorna o mes */
	echo date('Y')."<br>"; /* Retorna o ano */

	echo date('Y/m/d')."<br>";  /* Retorna a data com a formatação 2000/12/25 */ 
	echo date('m-d-Y')."<br>"; /* Retorna a data com a formatação 25-12-2000 */ 

	echo date('h')."<br>"; /* Retorna a hora */
	echo date('i')."<br>"; /* Retorna o minuto */
	echo date('s')."<br>"; /* Retorna o segundo */
	echo date('a')."<br>"; /* Retorna se esta antes ou depois do meio-dia. AM OU PM */

	date_default_timezone_set('America/New_York');  /* Atribui uma timezone */
	echo "<br>";
	echo date('h:i:sa')."<br>";  /* Retorna a hora atual */
	
	$timestamp = mktime(10,14,54,9,10,1981);  /* Cria uma data-hora. Ou seja neste exemplo eh, 10/09/1981 10:14:54 am */

	echo $timestamp."<br>";

	$timestamp2 = strtotime('7:00pm March 22 2019');  /* Cria uma data-hora */
	$timestamp3 = strtotime('tomorrow');  /* Retorna a data de amanhã */
	$timestamp4 = strtotime('next Tuesday');  /* Retorna a data da próxima Terça */
	$timestamp5 = strtotime('+2 Days');  /* Retorna a data daqui a dois dias */
	echo date('d/m/Y h:i:sa',$timestamp)."<br>";
	echo date('d/m/Y h:i:sa',$timestamp2)."<br>";
	echo date('d/m/Y h:i:sa',$timestamp3)."<br>";
	echo date('d/m/Y h:i:sa',$timestamp4)."<br>";
	echo date('d/m/Y h:i:sa',$timestamp5)."<br>";


?>
