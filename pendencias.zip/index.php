<?php
  require('fpdf/fpdf.php');
  require('conexaodb.php');

  if(isset($_POST["submit-pendencias"])){

	// Attempt insert query execution
  	try{
	    $data = date("Y-m-d H:i:s");
	    $booleano = 1;

	    // Create prepared statement
	    $sql = "INSERT INTO lista_pendencias (titulo_pendencias,descricao_pendencias,data_pendencias,prioridade_pendencias,ilustracao_pendencias) VALUES (:titulo_pendencias, :descricao_pendencias,:data_pendencias,:prioridade_pendencias,:ilustracao_pendencias)";
	    $stmt = $pdo->prepare($sql);
	    
	    // Bind parameters to statement
	    $stmt->bindParam(':titulo_pendencias', $_REQUEST['titulo_pendencias']);
	    $stmt->bindParam(':descricao_pendencias', $_REQUEST['descricao_pendencias']);
	    $stmt->bindParam(':prioridade_pendencias', $_REQUEST['prioridade_pendencias']);
	    $stmt->bindParam(':ilustracao_pendencias', $booleano);
	    $stmt->bindParam(':data_pendencias', $data);
	    
	    // Execute the prepared statement
	    $stmt->execute();
	    echo "Records inserted successfully.";
  	} catch(PDOException $e){
    	die("ERROR: Could not able to execute $sql. " . $e->getMessage());
  	}
}

if(isset($_POST["resolver"])){
	echo 'teste';
}

// Close connection
unset($pdo);

?>

<!DOCTYPE html>
<html>
<head>
  <title>Pendências</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="style.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.0/js/bootstrap.min.js"></script>
</head>

<body>
  <div id='conteudo' align="center">
    <h1>Pendências</h1>
    <h3>Registro de pendências do servidor ADPAT2</h3>
    </div>
    <ul class="nav nav-tabs">
    <li class="active"><a data-toggle="tab" href="#listar">Listar Pendências</a></li>
    <li><a data-toggle="tab" href="#adicionar-pendencia">Adicionar Item</a></li>
  </ul>
  <form method="post" action="index.php">
  <div class="tab-content">
    <div id="listar" class="tab-pane fade in active">
      <h3>Listar Pendências</h3>
      <p>Pendências presentes no servidor.</p>
      <?php   

    require('conexaodb.php');

    try { 
    $sql = "SELECT * FROM lista_pendencias ORDER BY prioridade_pendencias,data_pendencias"; 
    $res = $pdo->query($sql); 
    if ($res->rowCount() > 0) { 
        echo "<table>"; 
        echo "<tr>"; 
        echo "<th>Título</th>"; 
        echo "<th>Descrição</th>"; 
        echo "<th>Prioridade</th>"; 
        echo "<th>Data-Hora</th>"; 
        echo "<th></th>";
        echo "</tr>"; 
        while ($row = $res->fetch()) {
        	if($row['ilustracao_pendencias'] == 1){ 
	            echo "<tr>"; 
	            echo "<td>".$row['titulo_pendencias']."</td>"; 
	            echo "<td>".$row['descricao_pendencias']."</td>"; 
	            echo "<td>".$row['prioridade_pendencias']."</td>"; 
	            echo "<td>".$row['data_pendencias']."</td>"; 
	            echo "<td>"."<a href=\"deletar.php?id=$row[id_pendencias]\">Resolver</a>"."<td>";
	            echo "</tr>"; 
	        }
        } 
        echo "</table>"; 
        unset($res); 
    } 
    else { 
        echo "No matching records are found."; 
    } 
} 
catch (PDOException $e) { 
    die("ERROR: Could not able to execute $sql. ".$e->getMessage()); 
} 
unset($pdo); 
?> 

    </div>
    <div id="adicionar-pendencia" class="tab-pane fade">
      <h3>Adicionar Item</h3>
      <p>Opção para adicionar instalacao do servidor.</p>
      <ul>
        Título do Registro
        <li>
          <input type="text" name="titulo_pendencias"/>
        </li>
        Registro
        <li>
          <input type="textarea" name="descricao_pendencias" style="width: 300px;height: 100px;">
        </li>
        <br>
        <li>
        	Prioridade
        	<select name="prioridade_pendencias">
    			<option value="1">1</option>
    			<option value="2">2</option>
    			<option value="3">3</option>
  			</select>
        </li>
        <br>
        <li>
          <input type='submit' name='submit-pendencias' class="registrar" value='Registrar'></input>    
      </li>
      </ul>
    </div>
  </div>
</form>
  </div>
</body>
</html>
