<?php
	require('conexaodb.php');
	$id = intval($_GET['id']);

try {
	$sql = "UPDATE lista_pendencias SET ilustracao_pendencias=0 WHERE id_pendencias=$id";

	    // Prepare statement
    $stmt = $pdo->prepare($sql);

	    // execute the query
    $stmt->execute();

 	 header("Location: index.php"); /* Redirect browser */
    }
	catch(PDOException $e){
	    echo $sql . "<br>" . $e->getMessage();
	}
?>